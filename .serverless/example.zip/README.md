
# Overall



# How to install saved dependencies

pipenv install

- or if you want to install using lock file

pipenv sync

# How to add dependencies

pipenv install YOUR_DESIRED_DEPENDENCY (Eg: pipenv install Selenium)

# How to get into virtual env (PyCharm get into that when you have your console opened)

pipenv shell